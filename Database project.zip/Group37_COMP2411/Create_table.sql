create table Ingredient (
  I_Name varchar(30),
  Date_Of_Supply DATE,
  primary key (I_Name)
);

create table Supplier (
  S_ID int not null,
  S_name varchar(30),
  S_City varchar(30),
  primary key (S_ID)
);
 
create table Branch (
  B_ID int not null,
  Manager varchar(30),
  B_City varchar(30),
  primary key (B_ID)
);
 
CREATE table Employee (
  E_ID int not null,
  E_Name varchar(30),
  E_City varchar(30),
  Phone int,
  Job_Type varchar(30),
  Primary Key (E_ID)
);
 
CREATE table Disease (
	D_Name varchar(30) not null,
	D_Type varchar(30),
	primary key (D_Name)
);
 
CREATE table Customer (
  C_Name varchar(30),
  Phone_number int,
  C_City varchar(30),
  primary key (Phone_number)
);
 
CREATE table Product (
  P_name varchar(30) not null,
  is_prescription_drug int not null,
  Price int not null,
  Shelf_life varchar(30),
  Primary key (P_name)
);
 
create table Supplies_relationship (
  S_ID int not null,
  B_ID int not null,
  I_Name varchar(30) not null,
  FOREIGN KEY (S_ID) REFERENCES Supplier(S_ID),
  FOREIGN KEY (B_ID) REFERENCES Branch(B_ID),
  FOREIGN KEY (I_Name) REFERENCES Ingredient(I_Name)
);
 
CREATE table Uses_relationship (
  P_name varchar(30) not null,
  I_Name varchar(30),
  FOREIGN KEY (P_name) REFERENCES Product(P_name),
  FOREIGN KEY (I_Name) REFERENCES Ingredient(I_Name)
);
 
CREATE table work_for_relationship (
  E_ID int not null,
  B_ID int not null,
  FOREIGN Key (E_ID) references Employee(E_ID),
  FOREIGN KEY (B_ID) references Branch(B_ID)
);
 
CREATE TABLE cure (
  D_Name varchar(30) not null,
  P_name varchar(30) not null,
  FOREIGN KEY(D_Name) REFERENCES Disease(D_Name),
  FOREIGN KEY(P_name) REFERENCES Product(P_name)
);
 
CREATE table Research_relationship (
  E_ID int not null,
  P_name varchar(30) not null,
  FOREIGN Key (E_ID) references Employee(E_ID),
  FOREIGN Key (P_name) references Product(P_name)
);
 
CREATE table buy(
  P_name varchar(30),
  D_name varchar(30),
  T_ID int not null Primary key,
  phone_number int,
  Number_of_product int,
  with_prescription int,
  FOREIGN Key (P_name) REFERENCES Product(P_name),
  FOREIGN Key (D_name) REFERENCES Disease(D_name),
  FOREIGN Key ( phone_number) REFERENCES Customer( phone_number)
);

commit;