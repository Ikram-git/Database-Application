SQL:
Create_table.sql : used to create tables in oracle database.
Toydata.sql : used to insert toydata in oracle database. (Please create tables before running.)
Drop_table.sql : used to drop all tables that are created by Create_table.sql.

Java:
Branch_Manager:
Application for branch manager's view.
The main class is in Branch_Manager.java. Please set up an oracle account with the sql files before running.
Customer:
Application for customer's view.
The main class is in Customer.java.
