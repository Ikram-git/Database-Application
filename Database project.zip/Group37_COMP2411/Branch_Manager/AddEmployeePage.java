import javax.swing.*;
import java.awt.*;
import static javax.swing.JOptionPane.showMessageDialog;
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;


public class AddEmployeePage {
	
	private MyFrame frame;
	private int with_prescription=0;
	
    public AddEmployeePage() {
    	String username=Branch_Manager.username, pwd=Branch_Manager.pwd;
        EventQueue.invokeLater(() -> {
        	
            frame=new MyFrame("Add Employee");
            
            frame.setLayout(new GridLayout(0, 1));
            frame.setBackground(new Color(225,203,203));
            frame.setState(Frame.NORMAL);
            frame.setResizable(false);
            
            MyPanel panel=new MyPanel();
            panel.setLayout(null);
           
			JButton jb2=new JButton("Back");
			jb2.setPreferredSize(new Dimension(100,50));
			Dimension size = jb2.getPreferredSize();
            jb2.setBounds(600-size.width, 450, size.width, size.height);
            jb2.setFont(new Font("Arial", Font.PLAIN, 15));
            jb2.addActionListener(e->{
            	destroy();
            	new HomePage();
            });
			panel.add(jb2);
			
			JLabel label=new JLabel("Add Employee", SwingConstants.CENTER);
			label.setPreferredSize(new Dimension(500,50));
            label.setFont(new Font("Arial", Font.PLAIN, 30));
            size = label.getPreferredSize();
            label.setBounds((900-size.width)/2, 50, size.width, size.height);
			panel.add(label);
			
			
			JLabel eid=new JLabel("*Employee ID:", SwingConstants.LEFT);
			eid.setPreferredSize(new Dimension(200,30));
            eid.setFont(new Font("Arial", Font.PLAIN, 20));
            size = eid.getPreferredSize();
            eid.setBounds(250, 150, size.width, size.height);
			panel.add(eid);
			
			JTextField teid=new JTextField();
			teid.setPreferredSize(new Dimension(200,30));
            teid.setFont(new Font("Arial", Font.PLAIN, 20));
            size = teid.getPreferredSize();
            teid.setBounds(450, 150, size.width, size.height);
			panel.add(teid);
			
			JLabel name=new JLabel("Name:", SwingConstants.LEFT);
			name.setPreferredSize(new Dimension(200,30));
            name.setFont(new Font("Arial", Font.PLAIN, 20));
            size = name.getPreferredSize();
            name.setBounds(250, 200, size.width, size.height);
			panel.add(name);
			
			JTextField tname=new JTextField();
			tname.setPreferredSize(new Dimension(200,30));
            tname.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tname.getPreferredSize();
            tname.setBounds(450, 200, size.width, size.height);
			panel.add(tname);
			
			JLabel phone=new JLabel("Phone number:", SwingConstants.LEFT);
			phone.setPreferredSize(new Dimension(200,30));
            phone.setFont(new Font("Arial", Font.PLAIN, 20));
            size = phone.getPreferredSize();
            phone.setBounds(250, 250, size.width, size.height);
			panel.add(phone);
			
			JTextField tphone=new JTextField();
			tphone.setPreferredSize(new Dimension(200,30));
            tphone.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tphone.getPreferredSize();
            tphone.setBounds(450, 250, size.width, size.height);
			panel.add(tphone);
			
			
			JLabel position=new JLabel("Job position:", SwingConstants.LEFT);
			position.setPreferredSize(new Dimension(200,30));
            position.setFont(new Font("Arial", Font.PLAIN, 20));
            size = position.getPreferredSize();
            position.setBounds(250, 300, size.width, size.height);
			panel.add(position);
			
			JTextField tposition=new JTextField();
			tposition.setPreferredSize(new Dimension(200,30));
            tposition.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tposition.getPreferredSize();
            tposition.setBounds(450, 300, size.width, size.height);
			panel.add(tposition);
			
			JLabel city=new JLabel("City:", SwingConstants.LEFT);
			city.setPreferredSize(new Dimension(200,30));
            city.setFont(new Font("Arial", Font.PLAIN, 20));
            size = city.getPreferredSize();
            city.setBounds(250, 350, size.width, size.height);
			panel.add(city);
			
			JTextField tcity=new JTextField();
			tcity.setPreferredSize(new Dimension(200,30));
            tcity.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tcity.getPreferredSize();
            tcity.setBounds(450, 350, size.width, size.height);
			panel.add(tcity);
			
			
			JButton jb=new JButton("Confirm");
            jb.setPreferredSize(new Dimension(100,50));
            size = jb.getPreferredSize();
            jb.setBounds(300, 450, size.width, size.height);
            jb.setFont(new Font("Arial", Font.PLAIN, 15));
            jb.addActionListener(e->{
            	try{
					DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
					OracleConnection conn = 
						(OracleConnection)DriverManager.getConnection(
						 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
					int id;
					try{
						id=Integer.parseInt(teid.getText());
					}catch(NumberFormatException exc){
						showMessageDialog(frame, "Invalid Employee ID.");
						return;
					}
					Statement stmt = conn.createStatement();
					ResultSet rset=stmt.executeQuery("SELECT COUNT(*) FROM employee WHERE e_id="+id);
					while(rset.next()){
						int count=rset.getInt(1);
						if(count>0){
							showMessageDialog(frame, "Employee already exists.");
							return;
						}
					}
					String realphone=tphone.getText();
					if(realphone.equals(""))realphone="null";
					else realphone="'"+realphone+"'";
					stmt.executeQuery("INSERT INTO employee VALUES("+id+",'"+tname.getText()+"','"+tcity.getText()+"',"
						+realphone+",'"+tposition.getText()+"')");
					stmt.executeQuery("INSERT INTO work_for_relationship VALUES("+id+","+LoginPage.Bid+")");
					stmt.executeQuery("commit");
               		conn.close();
               		showMessageDialog(frame, "Employee added.");
            		destroy();
            		new HomePage();
            	}catch(SQLException ex){
            	   	showMessageDialog(frame, "An error occured.");
               		destroy();
               		new HomePage();
            	}
            });
			panel.add(jb);
			
			
			panel.setVisible(true);
			
			
			size = panel.getPreferredSize();
			panel.setBounds(0, 0, size.width, size.height);
			frame.add(panel);
			
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900,600);
            frame.setLocation(50,50);
            frame.setVisible(true);
        });
    }

	public final void destroy(){
		if(frame!=null) frame.dispose();
	}
}
