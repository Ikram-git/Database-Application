import java.io.*;
import java.io.Console;
import java.util.*;
/*
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;
*/

public class Branch_Manager
{
	//public static OracleConnection conn;
	public static String username, pwd;
	public static ArrayList<String> a=new ArrayList<String>();
	public static void main(String args[])
	{
		Console console = System.console();
		System.out.print("Enter your username: ");    // Your Oracle ID with double quote
        username = console.readLine();         // e.g. "98765432D"
        System.out.print("Enter your password: ");    // Password of your Oracle Account
        char[] password = console.readPassword();
		pwd = String.valueOf(password);
		
		a.add("e1");a.add("e2");a.add("blahblahblah");
		a.add("e1");a.add("e2");a.add("blahblahblah");
		a.add("e1");a.add("e2");a.add("blahblahblah");
		a.add("e1");a.add("e2");a.add("blahblahblah");
		a.add("e1");a.add("e2");a.add("blahblahblah");
		//new HomePage();
		new LoginPage();
		//new SearchPage("Employees",a);
		//new ProfilePage("Employee","Kevin",a.toString());
		//new AddSupplyPage("gzl",a);
	}
}
