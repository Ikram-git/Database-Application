import javax.swing.*;
import java.awt.*;


public class ProfilePage {
	
	private MyFrame frame;
    public ProfilePage(String profiletype, int id, String name, String contents) {
        EventQueue.invokeLater(() -> {
            frame=new MyFrame(profiletype+" Profile");
            frame.setResizable(false);
            frame.setLayout(new GridLayout(0, 1));
            frame.setBackground(new Color(225,203,203));
            frame.setState(Frame.NORMAL);
            
            MyPanel panel=new MyPanel();
            panel.setLayout(null);
            
			
			JButton jb2=new JButton("OK");
			jb2.setPreferredSize(new Dimension(100,50));
            Dimension size = jb2.getPreferredSize();
            jb2.setBounds(400, 450, size.width, size.height);
            jb2.setFont(new Font("Arial", Font.PLAIN, 15));
            jb2.addActionListener(e->{
                	destroy();
                	new HomePage();
            });
			panel.add(jb2);
			
			JButton jb=new JButton();
			if(profiletype.equals("Supplier")){
				jb=new JButton("Add Supply Record");
				jb.setPreferredSize(new Dimension(200,50));
	            size = jb.getPreferredSize();
	            jb.setBounds(350, 380, size.width, size.height);
	            jb.setFont(new Font("Arial", Font.PLAIN, 15));
	            jb.addActionListener(e->{
	            	destroy();
	            	new AddSupplyPage(id,name);
	            });
				panel.add(jb);
			}
			
			
			JLabel label=new JLabel("Profile: "+name, SwingConstants.CENTER);
			label.setPreferredSize(new Dimension(500,50));
            label.setFont(new Font("Arial", Font.PLAIN, 30));
            size = label.getPreferredSize();
            label.setBounds((900-size.width)/2, 50, size.width, size.height);
			panel.add(label);
			
			panel.setVisible(true);
			
			JTextArea ta=new JTextArea(contents);
			ta.setBackground(new Color(225,203,203));
			ta.setEditable(false);
			ta.setFont(new Font("Arial", Font.PLAIN, 20));
			size = ta.getPreferredSize();
			size = new Dimension(size.width+10, size.height+10);
			ta.setPreferredSize(size);
            ta.setBounds((900-size.width)/2, 150, size.width, size.height);
			panel.add(ta);
			
			size = panel.getPreferredSize();
			panel.setBounds(0, 0, size.width, size.height);
			frame.add(panel);
			
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900,600);
            frame.setLocation(50,50);
            frame.setVisible(true);
        });
    }

	public final void destroy(){
		if(frame!=null) frame.dispose();
	}
}
