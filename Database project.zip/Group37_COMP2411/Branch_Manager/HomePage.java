import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;
import static javax.swing.JOptionPane.showMessageDialog;

public class HomePage {
	
	private static MyFrame frame;
    public HomePage() {
        EventQueue.invokeLater(() -> {
        	String username=Branch_Manager.username, pwd=Branch_Manager.pwd;
            frame=new MyFrame("Home");
            frame.setLayout(new GridLayout(0, 1));
            frame.setBackground(new Color(225,203,203));
            frame.setResizable(false);
            frame.setState(Frame.NORMAL);
            
            MyPanel panel=new MyPanel();
            panel.setLayout(null);
            
            JButton jb1=new JButton("<html>View<br />Employees</html>");
            jb1.setHorizontalAlignment(SwingConstants.CENTER);
            jb1.setPreferredSize(new Dimension(200,100));
            jb1.setFont(new Font("Arial", Font.PLAIN, 30));
            jb1.addActionListener(e->{
            	ArrayList<String> a=new ArrayList<String>();
            	try{
					DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
					OracleConnection conn = 
						(OracleConnection)DriverManager.getConnection(
						 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
					
					Statement stmt = conn.createStatement();
					ResultSet rset = stmt.executeQuery("select e_id, e_name from employee where e_id in (Select e_id from work_for_relationship where b_id="+LoginPage.Bid+")");
                	while(rset.next()){
                		String s1=rset.getString(1),s2=rset.getString(2);
                		if(s2==null)s2="";
                		a.add(s1+" - "+s2);
                	}
                	conn.close();
                	destroy();
            		new SearchPage("Employee",a);
                }catch(SQLException ex){
                	showMessageDialog(frame, "An error occured.");
                }
            });
            Dimension size = jb1.getPreferredSize();
            jb1.setBounds(200, 270, size.width, size.height);
			panel.add(jb1);
			
			JButton jb3=new JButton("<html>View<br />Suppliers</html>");
			jb3.setHorizontalAlignment(SwingConstants.CENTER);
            jb3.setPreferredSize(new Dimension(200,100));
            jb3.setFont(new Font("Arial", Font.PLAIN, 30));
            size = jb3.getPreferredSize();
            jb3.setBounds(500, 270, size.width, size.height);
            jb3.addActionListener(e->{
            	ArrayList<String> a=new ArrayList<String>();
            	try{
					DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
					OracleConnection conn = 
						(OracleConnection)DriverManager.getConnection(
						 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
					
					Statement stmt = conn.createStatement();
					ResultSet rset = stmt.executeQuery("select s_id, s_name from supplier where s_id in (Select s_id from supplies_relationship where b_id="+LoginPage.Bid+")");
                	while(rset.next()){
                		String s1=rset.getString(1),s2=rset.getString(2);
                		if(s2==null)s2="";
                		a.add(s1+" - "+s2);
                	}
                	conn.close();
                	destroy();
            		new SearchPage("Supplier",a);
                }catch(SQLException ex){
                	ex.printStackTrace();
                	showMessageDialog(frame, "An error occured.");
                }
            });
			panel.add(jb3);
			
			JLabel label=new JLabel("Welcome", SwingConstants.CENTER);
			label.setPreferredSize(new Dimension(500,50));
            label.setFont(new Font("Arial", Font.PLAIN, 70));
            size = label.getPreferredSize();
            label.setBounds(200, 80, size.width, size.height);
			panel.add(label);
			
			panel.setVisible(true);
			
			size = panel.getPreferredSize();
			panel.setBounds(0, 0, size.width, size.height);
			frame.add(panel);
			
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900,600);
            frame.setLocation(50,50);
            frame.setVisible(true);
        });
    }

	public final void destroy(){
		if(frame!=null) frame.dispose();
	}
}
