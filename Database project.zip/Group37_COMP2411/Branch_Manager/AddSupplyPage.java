import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;
import static javax.swing.JOptionPane.showMessageDialog;

public class AddSupplyPage {
	
	private MyFrame frame;
	private String selected;
	
    public AddSupplyPage(int id, String sname) {
        EventQueue.invokeLater(() -> {
        	String username=Branch_Manager.username, pwd=Branch_Manager.pwd;
        	ArrayList<String> contents=new ArrayList<String>();
        	try{
				DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
				OracleConnection conn = 
					(OracleConnection)DriverManager.getConnection(
					 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
				
				Statement stmt = conn.createStatement();
				ResultSet rset = stmt.executeQuery("select i_name from ingredient");
               	while(rset.next()){
               		contents.add(rset.getString(1));
               	}
               	conn.close();
            }catch(SQLException ex){
               	showMessageDialog(frame, "An error occured.");
               	destroy();
               	new HomePage();
            }
            frame=new MyFrame("Add Supply Record");
            frame.setResizable(false);
            frame.setLayout(new GridLayout(0, 1));
            frame.setBackground(new Color(225,203,203));
            frame.setState(Frame.NORMAL);
            
            MyPanel panel=new MyPanel();
            panel.setLayout(null);
            
            JButton jb=new JButton("Confirm");
            			
					
			JButton jb2=new JButton("Back");
			jb2.setPreferredSize(new Dimension(100,50));
            Dimension size = jb2.getPreferredSize();
            jb2.setBounds(500, 450, size.width, size.height);
            jb2.setFont(new Font("Arial", Font.PLAIN, 15));
            jb2.addActionListener(e->{
                	destroy();
                	new HomePage();
            	});
			panel.add(jb2);
			
			
			JLabel label=new JLabel("Add supply record for "+sname, SwingConstants.CENTER);
			label.setPreferredSize(new Dimension(500,50));
            label.setFont(new Font("Arial", Font.PLAIN, 30));
            size = label.getPreferredSize();
            label.setBounds((900-size.width)/2, 50, size.width, size.height);
			panel.add(label);
			
			JLabel label2=new JLabel("Select Ingredient:", SwingConstants.CENTER);
			label2.setPreferredSize(new Dimension(500,50));
            label2.setFont(new Font("Arial", Font.PLAIN, 20));
            size = label2.getPreferredSize();
            label2.setBounds((900-size.width)/2-40, 100, size.width, size.height);
			panel.add(label2);
			
			DefaultListModel<String> model = new DefaultListModel<>();
			JList<String> jlist = new JList<>(model);
			for(String s:contents)
				model.addElement(s);
			jlist.setFont(new Font("Arial",Font.BOLD,20));
			jlist.addListSelectionListener(e->{
				jb.setEnabled(true);
				selected=jlist.getSelectedValue();
			});
			
			jb.setPreferredSize(new Dimension(100,50));
            size = jb.getPreferredSize();
            jb.setBounds(300, 450, size.width, size.height);
            jb.setFont(new Font("Arial", Font.PLAIN, 15));
            jb.setEnabled(false);
            jb.addActionListener(e->{
            	try{
					DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
					OracleConnection conn = 
						(OracleConnection)DriverManager.getConnection(
						 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
					
					Statement stmt = conn.createStatement();
					ResultSet rset=stmt.executeQuery("SELECT COUNT(*) FROM supplies_relationship WHERE s_id="+id+" AND b_id="+LoginPage.Bid+" AND i_name='"+selected+"'");
					while(rset.next()){
						int count=rset.getInt(1);
						if(count>0){
							showMessageDialog(frame, "Record already exists.");
							return;
						}
					}
					stmt.executeQuery("INSERT INTO supplies_relationship VALUES("+id+","+LoginPage.Bid+",'"+selected+"')");
					showMessageDialog(frame, "Successful.");
               		conn.close();
               		destroy();
            		new HomePage();
            	}catch(SQLException ex){
            	   	showMessageDialog(frame, "An error occured.");
               		destroy();
               		new HomePage();
            	}
            });
			panel.add(jb);
			
			JScrollPane list=new JScrollPane(jlist);
			
			size = list.getPreferredSize();
			list.setBounds((900-size.width)/2, 150, size.width, size.height);
			panel.add(list);
			panel.setVisible(true);
			
			
			size = panel.getPreferredSize();
			panel.setBounds(0, 0, size.width, size.height);
			frame.add(panel);
			
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900,600);
            frame.setLocation(50,50);
            frame.setVisible(true);
        });
    }

	public final void destroy(){
		if(frame!=null) frame.dispose();
	}
}
