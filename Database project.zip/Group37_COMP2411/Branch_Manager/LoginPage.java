import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;

import static javax.swing.JOptionPane.showMessageDialog;

public class LoginPage {
	public static int Bid=-1;
	private static MyFrame frame;
    public LoginPage() {
        EventQueue.invokeLater(() -> {
			String username=Branch_Manager.username, pwd=Branch_Manager.pwd;
            frame=new MyFrame("Home");
            frame.setLayout(new GridLayout(0, 1));
            frame.setBackground(new Color(225,203,203));
            frame.setResizable(false);
            frame.setState(Frame.NORMAL);
            MyPanel panel=new MyPanel();
            panel.setLayout(null);
            
            JLabel label=new JLabel("Branch Manager Login", SwingConstants.CENTER);
			label.setPreferredSize(new Dimension(500,50));
            label.setFont(new Font("Arial", Font.PLAIN, 30));
            Dimension size = label.getPreferredSize();
            label.setBounds((900-size.width)/2, 120, size.width, size.height);
			panel.add(label);
			
			JLabel bid=new JLabel("Branch ID:", SwingConstants.LEFT);
			bid.setPreferredSize(new Dimension(200,30));
            bid.setFont(new Font("Arial", Font.PLAIN, 20));
            size = bid.getPreferredSize();
            bid.setBounds(250, 200, size.width, size.height);
			panel.add(bid);
			
			JTextField tbid=new JTextField();
			tbid.setPreferredSize(new Dimension(200,30));
            tbid.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tbid.getPreferredSize();
            tbid.setBounds(450, 200, size.width, size.height);
			panel.add(tbid);
			
			JLabel manager=new JLabel("Login Name:", SwingConstants.LEFT);
			manager.setPreferredSize(new Dimension(200,30));
            manager.setFont(new Font("Arial", Font.PLAIN, 20));
            size = manager.getPreferredSize();
            manager.setBounds(250, 250, size.width, size.height);
			panel.add(manager);
			
			JTextField tmanager=new JTextField();
			tmanager.setPreferredSize(new Dimension(200,30));
            tmanager.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tmanager.getPreferredSize();
            tmanager.setBounds(450, 250, size.width, size.height);
			panel.add(tmanager);
			
			JButton jb=new JButton("Login");
            jb.setPreferredSize(new Dimension(100,50));
            size = jb.getPreferredSize();
            jb.setBounds(400, 400, size.width, size.height);
            jb.setFont(new Font("Arial", Font.PLAIN, 15));
            jb.addActionListener(e->{
            	int b_id;
            	String manager_name=tmanager.getText();
            	try{
            		b_id=Integer.parseInt(tbid.getText());
            	}catch(NumberFormatException ex){
            		showMessageDialog(frame,"Invalid branch ID or username.");
            		return;
            	}
            	
            	try{
					DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
					OracleConnection conn = 
						(OracleConnection)DriverManager.getConnection(
						 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
					
					Statement stmt = conn.createStatement();
					ResultSet rset = stmt.executeQuery("SELECT b_id,manager FROM branch");
					boolean flag=false;
                	while(rset.next()){
                		if(b_id==rset.getInt(1) && manager_name.equals(rset.getString(2))){
                			flag=true;
                			break;
                		}
                	}
                	conn.close();
                	if(flag){
                		showMessageDialog(frame, "Login successful.");
                		Bid=b_id;
                		destroy();
                		new HomePage();
                	}else{
                		showMessageDialog(frame, "Invalid branch ID or username.");
                	}
                	
                	
                }catch(SQLException ex){
                	showMessageDialog(frame, "An error occured.");
                	destroy();
                	new LoginPage();
                }
            });
            panel.add(jb);
			
			panel.setVisible(true);
			size = panel.getPreferredSize();
			panel.setBounds(0, 0, size.width, size.height);
			frame.add(panel);
			
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900,600);
            frame.setLocation(50,50);
            frame.setVisible(true);
        });
    }

	public final void destroy(){
		if(frame!=null) frame.dispose();
	}
}
