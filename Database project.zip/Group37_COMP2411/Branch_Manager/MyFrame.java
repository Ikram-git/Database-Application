import javax.swing.*;

public class MyFrame extends JFrame{
    public static final int WIDTH=900;
    public static final int HEIGHT=600;
    public MyFrame(String TITLE){
        super();
        initFrame(TITLE);
    }

    private void initFrame(String TITLE){
        setTitle(TITLE);
        setSize(WIDTH, HEIGHT);
        setDefaultCloseOperation(WindowConstants.EXIT_ON_CLOSE);
        setLocationRelativeTo(null);
    }
}
