import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;
import static javax.swing.JOptionPane.showMessageDialog;

public class SearchPage {
	
	private MyFrame frame;
	private String selected;
	
    public SearchPage(String searchobject, ArrayList<String> contents) {
        EventQueue.invokeLater(() -> {
        	String username=Branch_Manager.username, pwd=Branch_Manager.pwd;
            frame=new MyFrame("View "+searchobject);
            frame.setResizable(false);
            frame.setLayout(new GridLayout(0, 1));
            frame.setBackground(new Color(225,203,203));
            frame.setState(Frame.NORMAL);
            
            MyPanel panel=new MyPanel();
            panel.setLayout(null);
            
            JButton jb=new JButton("Profile");
            			
			JButton jb1=new JButton("Remove");
					
			JButton jb2=new JButton("Back");
			jb2.setPreferredSize(new Dimension(100,50));
            Dimension size = jb2.getPreferredSize();
            jb2.setBounds(550, 450, size.width, size.height);
            jb2.setFont(new Font("Arial", Font.PLAIN, 15));
            jb2.addActionListener(e->{
                	destroy();
                	new HomePage();
            	});
			panel.add(jb2);
			
			JButton jb3=new JButton("Add New");
            jb3.setPreferredSize(new Dimension(90,40));
            size = jb3.getPreferredSize();
            jb3.setBounds(405, 370, size.width, size.height);
            jb3.setFont(new Font("Arial", Font.BOLD, 12));
            jb3.addActionListener(e->{
            	destroy();
            	if(searchobject.equals("Employee"))new AddEmployeePage();
            	else new AddSupplierPage();
            });
			panel.add(jb3);
			
			
			JLabel label=new JLabel("View "+searchobject, SwingConstants.CENTER);
			label.setPreferredSize(new Dimension(500,50));
            label.setFont(new Font("Arial", Font.PLAIN, 30));
            size = label.getPreferredSize();
            label.setBounds((900-size.width)/2, 50, size.width, size.height);
			panel.add(label);
			
			DefaultListModel<String> model = new DefaultListModel<>();
			JList<String> jlist = new JList<>(model);
			for(String s:contents)
				model.addElement(s);
			jlist.setFont(new Font("Arial",Font.BOLD,20));
			jlist.addListSelectionListener(e->{
				jb.setEnabled(true);
				jb1.setEnabled(true);
				selected=jlist.getSelectedValue();
			});
			
			jb.setPreferredSize(new Dimension(100,50));
            size = jb.getPreferredSize();
            jb.setBounds(250, 450, size.width, size.height);
            jb.setFont(new Font("Arial", Font.PLAIN, 15));
            jb.setEnabled(false);
            jb.addActionListener(e->{
            	try{
            		int id=Integer.parseInt(selected.split(" - ")[0]);
            		String name=selected.split(" - ")[1];
					DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
					OracleConnection conn = 
						(OracleConnection)DriverManager.getConnection(
						 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
					
					Statement stmt = conn.createStatement();
					String query;
					if(searchobject.equals("Employee")){
						query="SELECT e_id,e_name,e_city,phone,job_type FROM employee WHERE e_id="+id;
					}else{
						query="SELECT s_id,s_name,s_city FROM supplier WHERE s_id="+id;
					}
					String content="";
					ResultSet rset = stmt.executeQuery(query);
                	while(rset.next()){
                		if(searchobject.equals("Employee")){
                			content="Employee ID:\n"+rset.getInt(1)+"\n"+"Name:\n"+rset.getString(2)+"\n"+"City:\n"+
                				rset.getString(3)+"\n"+"Phone number:\n"+rset.getInt(4)+"\n"+"Job position:\n"+rset.getString(5)+"\n";
                		}else{
                			content="Supplier ID:\n"+rset.getInt(1)+"\n"+"Name:\n"+rset.getString(2)+"\n"+"City:\n"+rset.getString(3)+"\n";
                		}
                	}
                	conn.close();
                	destroy();
            		new ProfilePage(searchobject, id, name, content);
                }catch(SQLException ex){
                	showMessageDialog(frame, "An error occured.");
                	destroy();
                	new HomePage();
                }
            });
			panel.add(jb);
			
            jb1.setPreferredSize(new Dimension(100,50));
            size = jb.getPreferredSize();
            jb1.setBounds(400, 450, size.width, size.height);
            jb1.setFont(new Font("Arial", Font.PLAIN, 15));
            jb1.setEnabled(false);
            jb1.addActionListener(e->{
            	try{
            		int id=Integer.parseInt(selected.split(" - ")[0]);
            		String name=selected.split(" - ")[1];
					DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
					OracleConnection conn = 
						(OracleConnection)DriverManager.getConnection(
						 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
					
					Statement stmt = conn.createStatement();
					if(searchobject.equals("Employee")){
						stmt.executeQuery("DELETE FROM work_for_relationship WHERE e_id="+id);
						stmt.executeQuery("DELETE FROM employee WHERE e_id="+id);
					}else{
						stmt.executeQuery("DELETE FROM supplies_relationship WHERE s_id="+id);
						stmt.executeQuery("DELETE FROM supplier WHERE s_id="+id);
					}
					stmt.executeQuery("commit");
                	conn.close();
                	jb.setEnabled(false);
            		jb1.setEnabled(false);
            		showMessageDialog(frame,searchobject+" removed.");
            		model.remove(jlist.getSelectedIndex());
                	destroy();
            		new HomePage();
                }catch(SQLException ex){
                	showMessageDialog(frame, "An error occured.");
                	destroy();
                	new HomePage();
                }
            	
            });
			panel.add(jb1);
			
			JScrollPane list=new JScrollPane(jlist);
			
			size = list.getPreferredSize();
			list.setBounds((900-size.width)/2, 150, size.width, size.height);
			panel.add(list);
			panel.setVisible(true);
			
			
			size = panel.getPreferredSize();
			panel.setBounds(0, 0, size.width, size.height);
			frame.add(panel);
			
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900,600);
            frame.setLocation(50,50);
            frame.setVisible(true);
        });
    }

	public final void destroy(){
		if(frame!=null) frame.dispose();
	}
}
