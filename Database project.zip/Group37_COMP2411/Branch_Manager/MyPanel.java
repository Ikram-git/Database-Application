import javax.swing.*;
import javax.swing.event.*;
import java.awt.*;

/**
 * for drawing Shapes
 */
public class MyPanel extends JPanel implements ChangeListener {
    private final RenderingHints hints;

    private final Dimension size; // encapsulate the width and height of a component

    private static final int WIDTH=900;
    private static final int HEIGHT=600;

    /**
     * @param a the Shapes will be drawn
     */
    public MyPanel(){
        super();

        hints = new RenderingHints(null);
        hints.put(RenderingHints.KEY_ANTIALIASING,
                RenderingHints.VALUE_ANTIALIAS_ON);
        hints.put(RenderingHints.KEY_TEXT_ANTIALIASING,
                RenderingHints.VALUE_TEXT_ANTIALIAS_ON);
        hints.put(RenderingHints.KEY_FRACTIONALMETRICS,
                RenderingHints.VALUE_FRACTIONALMETRICS_ON);


        size=new Dimension(WIDTH, HEIGHT);
        setBackground(new Color(225,203,203));
        setVisible(true);


    }

    @Override
    public final void stateChanged(ChangeEvent e){ // get the message of the change of event
        
    }
}
