import javax.swing.*;
import java.awt.*;
import static javax.swing.JOptionPane.showMessageDialog;
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;
import java.util.*;

public class AddSupplierPage{
	
	private MyFrame frame;
	private int with_prescription=0;
	private String selected="";
	
    public AddSupplierPage() {
    	String username=Branch_Manager.username, pwd=Branch_Manager.pwd;
        EventQueue.invokeLater(() -> {
        	ArrayList<String> ingredients=new ArrayList<String>();
                    
            frame=new MyFrame("Add Supplier");
            
            frame.setLayout(new GridLayout(0, 1));
            frame.setBackground(new Color(225,203,203));
            frame.setState(Frame.NORMAL);
            frame.setResizable(false);
            
            MyPanel panel=new MyPanel();
            panel.setLayout(null);
           
			JButton jb2=new JButton("Back");
			jb2.setPreferredSize(new Dimension(100,50));
			Dimension size = jb2.getPreferredSize();
            jb2.setBounds(600-size.width, 450, size.width, size.height);
            jb2.setFont(new Font("Arial", Font.PLAIN, 15));
            jb2.addActionListener(e->{
            	destroy();
            	new HomePage();
            });
			panel.add(jb2);
			
			JLabel label=new JLabel("Add Supplier", SwingConstants.CENTER);
			label.setPreferredSize(new Dimension(500,50));
            label.setFont(new Font("Arial", Font.PLAIN, 30));
            size = label.getPreferredSize();
            label.setBounds((900-size.width)/2, 50, size.width, size.height);
			panel.add(label);	
						
			JLabel sid=new JLabel("*Supplier ID:", SwingConstants.LEFT);
			sid.setPreferredSize(new Dimension(200,30));
            sid.setFont(new Font("Arial", Font.PLAIN, 20));
            size = sid.getPreferredSize();
            sid.setBounds(250, 150, size.width, size.height);
			panel.add(sid);
			
			JTextField tsid=new JTextField();
			tsid.setPreferredSize(new Dimension(200,30));
            tsid.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tsid.getPreferredSize();
            tsid.setBounds(450, 150, size.width, size.height);
			panel.add(tsid);
			
			JLabel name=new JLabel("Name:", SwingConstants.LEFT);
			name.setPreferredSize(new Dimension(200,30));
            name.setFont(new Font("Arial", Font.PLAIN, 20));
            size = name.getPreferredSize();
            name.setBounds(250, 200, size.width, size.height);
			panel.add(name);
			
			JTextField tname=new JTextField();
			tname.setPreferredSize(new Dimension(200,30));
            tname.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tname.getPreferredSize();
            tname.setBounds(450, 200, size.width, size.height);
			panel.add(tname);
			
			JLabel city=new JLabel("City:", SwingConstants.LEFT);
			city.setPreferredSize(new Dimension(200,30));
            city.setFont(new Font("Arial", Font.PLAIN, 20));
            size = city.getPreferredSize();
            city.setBounds(250, 250, size.width, size.height);
			panel.add(city);
			
			JTextField tcity=new JTextField();
			tcity.setPreferredSize(new Dimension(200,30));
            tcity.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tcity.getPreferredSize();
            tcity.setBounds(450, 250, size.width, size.height);
			panel.add(tcity);
			
			JLabel ing=new JLabel("*Ingredient:", SwingConstants.LEFT);
			ing.setPreferredSize(new Dimension(200,30));
            ing.setFont(new Font("Arial", Font.PLAIN, 20));
            size = ing.getPreferredSize();
            ing.setBounds(250, 300, size.width, size.height);
			panel.add(ing);
			
			JTextField ting=new JTextField();
			ting.setPreferredSize(new Dimension(200,30));
            ting.setFont(new Font("Arial", Font.PLAIN, 20));
            size = ting.getPreferredSize();
            ting.setBounds(450, 300, size.width, size.height);
			panel.add(ting);
				
			
			JButton jb=new JButton("Confirm");
            jb.setPreferredSize(new Dimension(100,50));
            size = jb.getPreferredSize();
            jb.setBounds(300, 450, size.width, size.height);
            jb.setFont(new Font("Arial", Font.PLAIN, 15));
            jb.addActionListener(e->{
            	try{
					DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
					OracleConnection conn = 
						(OracleConnection)DriverManager.getConnection(
						 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
					int id;
					
					try{
						id=Integer.parseInt(tsid.getText());
					}catch(NumberFormatException exc){
						showMessageDialog(frame, "Invalid Supplier ID.");
						return;
					}
					
					if(ting.getText().equals("")){
						showMessageDialog(frame, "Please enter ingredient.");
						return;
					}
					Statement stmt = conn.createStatement();
					ResultSet rset=stmt.executeQuery("SELECT count(i_name) from ingredient where i_name='"+ting.getText()+"'");
					while(rset.next()){
						if(rset.getInt(1)==0){
							showMessageDialog(frame, "Unknown ingredient. Please contact product manager.");
							return;
						}
					}
					rset=stmt.executeQuery("SELECT COUNT(*) FROM supplier WHERE s_id="+id);
					while(rset.next()){
						int count=rset.getInt(1);
						if(count>0){
							showMessageDialog(frame, "Supplier already exists.");
							return;
						}
					}
					stmt.executeQuery("INSERT INTO supplier VALUES("+id+",'"+tname.getText()+"','"+tcity.getText()+"')");
					stmt.executeQuery("INSERT INTO supplies_relationship VALUES("+id+","+LoginPage.Bid+",'"+ting.getText()+"')");
					stmt.executeQuery("commit");
               		conn.close();
               		showMessageDialog(frame, "Supplier added.");
            		destroy();
            		new HomePage();
            	}catch(SQLException ex){
            		ex.printStackTrace();
            	   	showMessageDialog(frame, "An error occured.");
               		destroy();
               		new HomePage();
            	}
            });
            
			panel.add(jb);
			panel.setVisible(true);
			
			size = panel.getPreferredSize();
			panel.setBounds(0, 0, size.width, size.height);
			frame.add(panel);
			
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900,600);
            frame.setLocation(50,50);
            frame.setVisible(true);
        });
    }

	public final void destroy(){
		if(frame!=null) frame.dispose();
	}
}
