insert all
into Ingredient (i_name, date_of_supply)Values('T-Virus-reinforce',to_date('16/07/1998', 'DD/MM/YYYY'))
into Ingredient(i_name, date_of_supply) Values ('G_Virs', to_date('06/01/2006', 'DD/MM/YYYY'))
into ingredient (I_Name, date_of_supply) Values ('T-Virus', to_date('03/10/1997', 'DD/MM/YYYY'))
SELECT 1 FROM dual;
 
insert all
into branch (B_ID, Manager, B_City) Values (0201, 'Jenify Chen', 'Hong Kong')
into branch (B_ID, Manager, B_City) Values (0202, 'Tse Wei ni', 'New York')
into branch (B_ID, Manager, B_City) Values (0203, 'Wesker', 'Raccoon City')
SELECT 1 FROM dual;
 
insert all
into customer (C_Name, Phone_number, C_City) Values ('BSAA', 0101, 'New York')
into customer (C_Name, Phone_number, C_City) Values ('Blue-umbrella', 0168455, 'New York')
into customer (C_Name, Phone_number, C_City) Values ('NFO', 023666, 'New York')
SELECT 1 FROM dual;
 
insert all
into Disease (D_Name, D_type) Values ('T-infected', 'DNA')
into Disease (D_Name, D_type) Values ('G-infected', 'DNA')
into Disease (D_Name, D_type) Values ('LL', 'RNA')
SELECT 1 froM Dual;
 
insert all
into employee (E_ID, E_name, E_City, Phone, Job_type) Values (501, 'Jack andwer', 'Raccon city', 62501332, 'Executor')
into employee (E_ID, E_name, E_City, Phone, Job_type) Values (531, 'Tony luther', 'Raccon city', 62502236, 'Researcher')
into employee (E_ID, E_name, E_City, Phone, Job_type) Values (522, 'Jack andwer', 'Raccon city', 62501332, 'Manager')
SELECT 1 FROM Dual;
 
insert all
into Product (P_name, is_prescription_drug, Price,shelf_life) values ('Jagdpanzer 38(t) Hetzer', 1, 150000, '3 Years')
into Product (P_name, is_prescription_drug, Price,shelf_life) values ('Tyrant', 1, 600000,'1 year')
into Product (P_name, is_prescription_drug, Price, shelf_life) values ('Hetzer', 1, 316500, '10 Months')
SELECT 1 FROM Dual;

 
insert all
into Supplier(S_ID, S_name, S_City) Values (1901, 'umbrella-Africa', 'Relic_in_Dubai-West Africa')
into Supplier(S_ID, S_name, S_City) Values (1925, 'Siess', 'North-pole')
into Supplier(S_ID, S_name, S_City) values (1933, 'Altatic', 'South-America')
SELECT 1 FROM Dual;
 
insert all
into supplies_relationship (S_ID, B_ID, I_Name) Values(1901, 0203, 'T-Virus')
into supplies_relationship (S_ID, B_ID, I_Name) Values(1925, 0203, 'T-Virus-reinforce')
into supplies_relationship (S_ID, B_ID, I_Name) Values(1933, 0202, 'G_Virs')
SELECT 1 FROM Dual;
 
insert all
into research_relationship(E_ID, P_name) Values (501, 'Tyrant')
into research_relationship(E_ID, P_name) Values (531, 'Jagdpanzer 38(t) Hetzer')
into research_relationship(E_ID, P_name) Values (522, 'Hetzer')
SELECT 1 FROM Dual;
 
insert all
into work_for_relationship(E_ID, B_ID) Values (501, 0203)
into work_for_relationship(E_ID, B_ID) Values (531, 0201)
into work_for_relationship(E_ID, B_ID) Values (522, 0202)
SELECT 1 FROM Dual;
 
insert all
into uses_relationship(P_name, I_Name) Values ('Tyrant', 'T-Virus')
into uses_relationship(P_name, I_Name) Values ('Jagdpanzer 38(t) Hetzer', 'G_Virs')
into uses_relationship(P_name, I_Name) Values ('Hetzer', 'T-Virus-reinforce')
SELECT 1 FROM Dual;
 
insert all
into cure (D_Name, P_name) Values ('T-infected', 'Tyrant')
into cure (D_Name, P_name) Values ('G-infected', 'Jagdpanzer 38(t) Hetzer')
into cure (D_Name, P_name) Values ('LL', 'Hetzer')
SELECT 1 FROM Dual;
 
insert all
into buy (P_name, D_Name, T_ID, phone_number, Number_Of_Product, With_prescription) Values ('Tyrant', 'T-infected',2001, 0101, 5, 1)
into buy (P_name, D_Name, T_ID, phone_number, Number_Of_Product, With_prescription) Values ('Jagdpanzer 38(t) Hetzer','G-infected', 2032,0168455, 2, 1)
into buy (P_name, D_Name, T_ID, phone_number, Number_Of_Product, With_prescription) Values ('Hetzer', 'LL', 2033, 023666, 3, 1)
SELECT 1 FROM Dual; 

commit;