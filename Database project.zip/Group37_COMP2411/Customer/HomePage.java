import javax.swing.*;
import java.awt.*;
import java.awt.event.*;
import java.util.*;
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;
import static javax.swing.JOptionPane.showMessageDialog;

public class HomePage {
	
	private static MyFrame frame;
    public HomePage() { // frame+panel
        EventQueue.invokeLater(() -> {
        	String username=Customer.username, pwd=Customer.pwd;
            frame=new MyFrame("Home");
            frame.setLayout(new GridLayout(0, 1));
            frame.setBackground(new Color(225,203,203));
            frame.setResizable(false);
            frame.setState(Frame.NORMAL);
            
            MyPanel panel=new MyPanel();
            panel.setLayout(null);
            
            JButton jb1=new JButton("<html>Search by<br />Disease</html>");
            jb1.setHorizontalAlignment(SwingConstants.CENTER);
            jb1.setPreferredSize(new Dimension(200,100));
            jb1.setFont(new Font("Arial", Font.PLAIN, 30));
            jb1.addActionListener(e->{
                	ArrayList<String> a=new ArrayList<String>();
                	try{
						DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
						OracleConnection conn = 
							(OracleConnection)DriverManager.getConnection(
							 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
						
						Statement stmt = conn.createStatement();
						ResultSet rset = stmt.executeQuery("SELECT D_name from DISEASE");
                		while(rset.next()){
                			a.add(rset.getString(1));
                		}
                		conn.close();
                		destroy();
                		new SearchPage("Search by disease",null,a);
                	}catch(SQLException ex){
                		showMessageDialog(frame, "An error occured.");
                		destroy();
                		new HomePage();
                	}
            	});
            Dimension size = jb1.getPreferredSize();
            jb1.setBounds(100, 270, size.width, size.height);
			panel.add(jb1);
			
			JButton jb2=new JButton("<html>View<br />Orders</html>");
			jb2.setHorizontalAlignment(SwingConstants.CENTER);
            jb2.setPreferredSize(new Dimension(150,100));
            jb2.setFont(new Font("Arial", Font.PLAIN, 30));
            size = jb2.getPreferredSize();
            jb2.setBounds(375, 270, size.width, size.height);
			jb2.addActionListener(e->{
                	destroy();
                	new ViewOrderPage();
            	});
			panel.add(jb2);
			
			JButton jb3=new JButton("<html>Search by<br />Product</html>");
			jb3.setHorizontalAlignment(SwingConstants.CENTER);
            jb3.setPreferredSize(new Dimension(200,100));
            jb3.setFont(new Font("Arial", Font.PLAIN, 30));
            size = jb3.getPreferredSize();
            jb3.setBounds(600, 270, size.width, size.height);
            jb3.addActionListener(e->{
                	ArrayList<String> a=new ArrayList<String>();
                	try{
                		
						DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
						OracleConnection conn = 
							(OracleConnection)DriverManager.getConnection(
							 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
						
						Statement stmt = conn.createStatement();
						ResultSet rset = stmt.executeQuery("SELECT p_name from product");
                		while(rset.next()){
                			a.add(rset.getString(1));
                		}
                		conn.close();
                		destroy();
                		new SearchPage("Search by product",null,a);
                	}catch(SQLException ex){
                		showMessageDialog(frame, "An error occured.");
                		destroy();
                		new HomePage();
                	}
            	});
			panel.add(jb3);
			
			
			JLabel label=new JLabel("Welcome", SwingConstants.CENTER);
			label.setPreferredSize(new Dimension(500,50));
            label.setFont(new Font("Arial", Font.PLAIN, 70));
            size = label.getPreferredSize();
            label.setBounds(200, 80, size.width, size.height);
			panel.add(label);
			
			panel.setVisible(true);
			
			size = panel.getPreferredSize();
			panel.setBounds(0, 0, size.width, size.height);
			frame.add(panel);
			
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900,600);
            frame.setLocation(50,50);
            frame.setVisible(true);
        });
    }

	public final void destroy(){
		if(frame!=null) frame.dispose();
	}
}
