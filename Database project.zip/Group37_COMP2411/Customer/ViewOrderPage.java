import javax.swing.*;
import java.awt.*;
import static javax.swing.JOptionPane.showMessageDialog;
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;

public class ViewOrderPage {
	
	private MyFrame frame;
    public ViewOrderPage() {
        EventQueue.invokeLater(() -> {
        	String username=Customer.username, pwd=Customer.pwd;
            frame=new MyFrame("View Orders");
            frame.setResizable(false);
            frame.setLayout(new GridLayout(0, 1));
            frame.setBackground(new Color(225,203,203));
            frame.setState(Frame.NORMAL);
            
            MyPanel panel=new MyPanel();
            panel.setLayout(null);
            
            
            JTextArea ta=new JTextArea("blahblahblahblncksncslncsncscsah\nblah");
			ta.setVisible(false);
			ta.setColumns(20);
			ta.setEditable(false);
			ta.setFont(new Font("Arial", Font.PLAIN, 20));
			Dimension size = ta.getPreferredSize();
            ta.setBounds((900-size.width)/2, 220, size.width, size.height);
			panel.add(ta);
			
            		
			JButton jb2=new JButton("Back");
			jb2.setPreferredSize(new Dimension(100,50));
            size = jb2.getPreferredSize();
            jb2.setBounds(600-size.width, 450, size.width, size.height);
            jb2.setFont(new Font("Arial", Font.PLAIN, 15));
            jb2.addActionListener(e->{
                	destroy();
                	new HomePage();
            	});
			panel.add(jb2);
			
			JLabel phone=new JLabel("Phone number: ",SwingConstants.LEFT);
			phone.setPreferredSize(new Dimension(200,30));
            phone.setFont(new Font("Arial", Font.PLAIN, 20));
            size = phone.getPreferredSize();
            phone.setBounds(250, 150, size.width, size.height);
			panel.add(phone);
			
			JTextField tphone=new JTextField();
			tphone.setPreferredSize(new Dimension(200,30));
            tphone.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tphone.getPreferredSize();
            tphone.setBounds(450, 150, size.width, size.height);
			panel.add(tphone);
						
			
			JButton jb=new JButton("Next");
            jb.setPreferredSize(new Dimension(100,50));
            size = jb.getPreferredSize();
            jb.setBounds(300, 450, size.width, size.height);
            jb.setFont(new Font("Arial", Font.PLAIN, 15));
            jb.addActionListener(e->{
            	String t=tphone.getText();
            	try{
            		Integer.parseInt(t);
            	}catch(NumberFormatException ex){
            		showMessageDialog(frame, "Invalid phone number.");
            		return;
            	}
            	if(t.equals("")||t==null)
            		showMessageDialog(frame, "Please fill in your phone number.");
            	else{
            		String text="";
            		try{
                		
						DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
						OracleConnection conn = 
							(OracleConnection)DriverManager.getConnection(
							 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
						
						Statement stmt = conn.createStatement();
						ResultSet rset = stmt.executeQuery("SELECT p_name, number_of_product from buy where phone_number="+t);
                		while(rset.next()){
                			text+="Product: "+rset.getString(1)+"      Quantity: "+rset.getInt(2)+"\n";
                		}
                		conn.close();
                		if(text.equals(""))
                			showMessageDialog(frame, "No records found.");
                		else{
                			ta.setText(text);
                			ta.setVisible(true);
            				jb.setEnabled(false);
                		}
                		
                	}catch(SQLException ex){
                		ex.printStackTrace();
                		showMessageDialog(frame, "An error occured.");
                		destroy();
                		new HomePage();
                	}
            	}
            });
			panel.add(jb);
			
			
			size = panel.getPreferredSize();
			panel.setBounds(0, 0, size.width, size.height);
			frame.add(panel);
			
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900,600);
            frame.setLocation(50,50);
            frame.setVisible(true);
        });
    }

	public final void destroy(){
		if(frame!=null) frame.dispose();
	}
}
