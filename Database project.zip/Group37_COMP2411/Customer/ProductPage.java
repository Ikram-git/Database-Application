import javax.swing.*;
import java.awt.*;


public class ProductPage {
	
	private MyFrame frame;
    public ProductPage(String name, String dname, int price, int is_prescription, String contents) {
        EventQueue.invokeLater(() -> {
            frame=new MyFrame("Product information");
            frame.setResizable(false);
            frame.setLayout(new GridLayout(0, 1));
            frame.setBackground(new Color(225,203,203));
            frame.setState(Frame.NORMAL);
            
            MyPanel panel=new MyPanel();
            panel.setLayout(null);
            
            JButton jb=new JButton("Proceed");
            jb.setPreferredSize(new Dimension(100,50));
            Dimension size = jb.getPreferredSize();
            jb.setBounds(300, 450, size.width, size.height);
            jb.setFont(new Font("Arial", Font.PLAIN, 15));
            jb.addActionListener(e->{
                	destroy();
                	new PurchasePage(name,dname,price,is_prescription);
            	});
			panel.add(jb);
			
			JButton jb2=new JButton("Cancel");
			jb2.setPreferredSize(new Dimension(100,50));
            size = jb2.getPreferredSize();
            jb2.setBounds(600-size.width, 450, size.width, size.height);
            jb2.setFont(new Font("Arial", Font.PLAIN, 15));
            jb2.addActionListener(e->{
                	destroy();
                	new HomePage();
            	});
			panel.add(jb2);
			
			
			JLabel label=new JLabel(name, SwingConstants.CENTER);
			label.setPreferredSize(new Dimension(500,50));
            label.setFont(new Font("Arial", Font.PLAIN, 30));
            size = label.getPreferredSize();
            label.setBounds((900-size.width)/2, 50, size.width, size.height);
			panel.add(label);
			
			panel.setVisible(true);
			
			JTextArea ta=new JTextArea(contents);
			ta.setBackground(new Color(225,203,203));
			ta.setEditable(false);
			ta.setFont(new Font("Arial", Font.PLAIN, 20));
			size = ta.getPreferredSize();
            ta.setBounds((900-size.width)/2, 150, size.width, size.height);
			panel.add(ta);
			
			size = panel.getPreferredSize();
			panel.setBounds(0, 0, size.width, size.height);
			frame.add(panel);
			
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900,600);
            frame.setLocation(50,50);
            frame.setVisible(true);
        });
    }

	public final void destroy(){
		if(frame!=null) frame.dispose();
	}
}
