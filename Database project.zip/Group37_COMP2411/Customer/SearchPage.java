import javax.swing.*;
import java.awt.*;
import java.util.*;
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;
import static javax.swing.JOptionPane.showMessageDialog;

public class SearchPage {
	
	private MyFrame frame;
	private String selected;
	
    public SearchPage(String title, String dname, ArrayList<String> contents) {
        EventQueue.invokeLater(() -> {
        	String username=Customer.username, pwd=Customer.pwd;
            frame=new MyFrame(title);
            frame.setResizable(false);
            frame.setLayout(new GridLayout(0, 1));
            frame.setBackground(new Color(225,203,203));
            frame.setState(Frame.NORMAL);
            
            MyPanel panel=new MyPanel();
            panel.setLayout(null);
            
            JButton jb=new JButton("Confirm");
            jb.setPreferredSize(new Dimension(100,50));
            Dimension size = jb.getPreferredSize();
            jb.setBounds(300, 450, size.width, size.height);
            jb.setFont(new Font("Arial", Font.PLAIN, 15));
            jb.setEnabled(false);
            jb.addActionListener(e->{
                	if(title.equals("Search by disease")){
                		try{
                			ArrayList<String> a=new ArrayList<String>();
							DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
							OracleConnection conn = 
								(OracleConnection)DriverManager.getConnection(
								 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
							
							Statement stmt = conn.createStatement();
							ResultSet rset = stmt.executeQuery("SELECT DISTINCT p_name from cure where d_name='"+selected+"'");
	                		while(rset.next())
	                			a.add(rset.getString(1));
	                		conn.close();
	                		if(a.size()==0){
	                			showMessageDialog(frame, "No records found.");
	                			destroy();
	                			new HomePage();
	                		}
	                		else{
	                			destroy();
	                			new SearchPage(selected,selected,a);
	                		}
	                	}catch(SQLException ex){
	                		showMessageDialog(frame, "An error occured.");
	                		destroy();
	                		new HomePage();
	                	}
	                }else{
	                	try{
	                		String text="";
                			ArrayList<String> a=new ArrayList<String>();
							DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
							OracleConnection conn = 
								(OracleConnection)DriverManager.getConnection(
								 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
							
							Statement stmt = conn.createStatement();
							ResultSet rset = stmt.executeQuery("SELECT p_name,price,is_prescription_drug,shelf_life from product where p_name='"+selected+"'");
							int p=0,q=0;
							if(rset.next()){
								text+="Product: "+rset.getString(1)+"\nPrice: ";
								p=rset.getInt(2);
								text+=p+"\nNeeds prescription: ";
		                		q=rset.getInt(3);
		                		text+=q==0?"No":"Yes"+"\nShelf life: "+rset.getString(4);
							}else throw new SQLException();
	                		conn.close();
	                		destroy();
	                		new ProductPage(selected,dname,p,q,text);
	                		
	                	}catch(SQLException ex){
	                		showMessageDialog(frame, "An error occured.");
	                		destroy();
	                		new HomePage();
	                	}
	                }
            	});
			panel.add(jb);
			
			JButton jb2=new JButton("Back");
			jb2.setPreferredSize(new Dimension(100,50));
            size = jb2.getPreferredSize();
            jb2.setBounds(600-size.width, 450, size.width, size.height);
            jb2.setFont(new Font("Arial", Font.PLAIN, 15));
            jb2.addActionListener(e->{
                	destroy();
                	new HomePage();
            	});
			panel.add(jb2);
			
			
			JLabel label=new JLabel(title, SwingConstants.CENTER);
			label.setPreferredSize(new Dimension(500,50));
            label.setFont(new Font("Arial", Font.PLAIN, 30));
            size = label.getPreferredSize();
            label.setBounds((900-size.width)/2, 50, size.width, size.height);
			panel.add(label);
			
			DefaultListModel<String> model = new DefaultListModel<>();
			JList<String> jlist = new JList<>(model);
			for(String s:contents)
				model.addElement(s);
			jlist.setFont(new Font("Arial",Font.BOLD,20));
			jlist.addListSelectionListener(e->{
				jb.setEnabled(true);
				selected=jlist.getSelectedValue();
			});
			
			JScrollPane list=new JScrollPane(jlist);
			
			size = list.getPreferredSize();
			list.setBounds((900-size.width)/2, 150, size.width, size.height);
			panel.add(list);
			panel.setVisible(true);
			
			
			size = panel.getPreferredSize();
			panel.setBounds(0, 0, size.width, size.height);
			frame.add(panel);
			
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900,600);
            frame.setLocation(50,50);
            frame.setVisible(true);
        });
    }

	public final void destroy(){
		if(frame!=null) frame.dispose();
	}
}
