import java.io.*;
import java.io.Console;
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;

public class Customer
{
	public static OracleConnection conn;
	public static String username="",pwd="";
	public static void main(String[] args) throws SQLException, IOException
	{
		Console console = System.console();
		System.out.print("Enter your username: ");    // Your Oracle ID with double quote
        username = console.readLine();         // e.g. "98765432D"
        System.out.print("Enter your password: ");    // Password of your Oracle Account
        char[] password = console.readPassword();
		pwd = String.valueOf(password);
		new HomePage();
	}
}
