import javax.swing.*;
import java.awt.*;
import static javax.swing.JOptionPane.showMessageDialog;
import java.sql.*;
import oracle.jdbc.driver.*;
import oracle.sql.*;


public class PurchasePage {
	
	private MyFrame frame;
	private int with_prescription=0;
	
    public PurchasePage(String pname, String dname, int singleprice, int is_prescription) {
    	//enter name, phone number, location, quantity, with_prescription
        EventQueue.invokeLater(() -> {
        	String username=Customer.username, pwd=Customer.pwd;
            frame=new MyFrame("Purchase "+pname);
            
            frame.setLayout(new GridLayout(0, 1));
            frame.setBackground(new Color(225,203,203));
            frame.setState(Frame.NORMAL);
            frame.setResizable(false);
            
            MyPanel panel=new MyPanel();
            panel.setLayout(null);
           
			JButton jb2=new JButton("Cancel");
			jb2.setPreferredSize(new Dimension(100,50));
			Dimension size = jb2.getPreferredSize();
            jb2.setBounds(600-size.width, 450, size.width, size.height);
            jb2.setFont(new Font("Arial", Font.PLAIN, 15));
            jb2.addActionListener(e->{
            	destroy();
            	new HomePage();
            });
			panel.add(jb2);
			
			JLabel label=new JLabel("Complete your order", SwingConstants.CENTER);
			label.setPreferredSize(new Dimension(500,50));
            label.setFont(new Font("Arial", Font.PLAIN, 30));
            size = label.getPreferredSize();
            label.setBounds((900-size.width)/2, 50, size.width, size.height);
			panel.add(label);
			
			JLabel product=new JLabel(" Product name: "+pname, SwingConstants.LEFT);
			product.setPreferredSize(new Dimension(500,30));
            product.setFont(new Font("Arial", Font.PLAIN, 20));
            size = product.getPreferredSize();
            product.setBounds(250, 100, size.width, size.height);
			panel.add(product);
			
			JLabel price=new JLabel(" Single Price: "+singleprice, SwingConstants.LEFT);
			price.setPreferredSize(new Dimension(200,30));
            price.setFont(new Font("Arial", Font.PLAIN, 20));
            size = price.getPreferredSize();
            price.setBounds(250, 150, size.width, size.height);
			panel.add(price);
			
			JLabel name=new JLabel(" Name:", SwingConstants.LEFT);
			name.setPreferredSize(new Dimension(200,30));
            name.setFont(new Font("Arial", Font.PLAIN, 20));
            size = name.getPreferredSize();
            name.setBounds(250, 200, size.width, size.height);
			panel.add(name);
			
			JTextField tname=new JTextField();
			tname.setPreferredSize(new Dimension(200,30));
            tname.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tname.getPreferredSize();
            tname.setBounds(450, 200, size.width, size.height);
			panel.add(tname);
			
			JLabel phone=new JLabel("*Phone number:", SwingConstants.LEFT);
			phone.setPreferredSize(new Dimension(200,30));
            phone.setFont(new Font("Arial", Font.PLAIN, 20));
            size = phone.getPreferredSize();
            phone.setBounds(250, 250, size.width, size.height);
			panel.add(phone);
			
			JTextField tphone=new JTextField();
			tphone.setPreferredSize(new Dimension(200,30));
            tphone.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tphone.getPreferredSize();
            tphone.setBounds(450, 250, size.width, size.height);
			panel.add(tphone);
			
			
			JLabel quantity=new JLabel("*Quantity:", SwingConstants.LEFT);
			quantity.setPreferredSize(new Dimension(200,30));
            quantity.setFont(new Font("Arial", Font.PLAIN, 20));
            size = quantity.getPreferredSize();
            quantity.setBounds(250, 300, size.width, size.height);
			panel.add(quantity);
			
			JTextField tquantity=new JTextField();
			tquantity.setPreferredSize(new Dimension(200,30));
            tquantity.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tquantity.getPreferredSize();
            tquantity.setBounds(450, 300, size.width, size.height);
			panel.add(tquantity);
			
			JLabel city=new JLabel("City:", SwingConstants.LEFT);
			city.setPreferredSize(new Dimension(200,30));
            city.setFont(new Font("Arial", Font.PLAIN, 20));
            size = city.getPreferredSize();
            city.setBounds(250, 350, size.width, size.height);
			panel.add(city);
			
			JTextField tcity=new JTextField();
			tcity.setPreferredSize(new Dimension(200,30));
            tcity.setFont(new Font("Arial", Font.PLAIN, 20));
            size = tcity.getPreferredSize();
            tcity.setBounds(450, 350, size.width, size.height);
			panel.add(tcity);
			
			JCheckBox cb=new JCheckBox("I have prescription from my doctor");
			cb.setPreferredSize(new Dimension(500,30));
            cb.setFont(new Font("Arial", Font.PLAIN, 15));
            size = cb.getPreferredSize();
            cb.setBounds(250, 400, size.width, size.height);
            cb.setBackground(new Color(225,203,203));
            cb.addItemListener(e->{
            	with_prescription=cb.isSelected()?1:0;
            });
			panel.add(cb);
			
			JButton jb=new JButton("Confirm");
            jb.setPreferredSize(new Dimension(100,50));
            size = jb.getPreferredSize();
            jb.setBounds(300, 450, size.width, size.height);
            jb.setFont(new Font("Arial", Font.PLAIN, 15));
            jb.addActionListener(e->{
            	String t1=tquantity.getText(), t2=tphone.getText(), t3=tname.getText(), t4=tcity.getText();
            	try{
            		int i1=Integer.parseInt(t2), i2=Integer.parseInt(t1);
            		if(i1<=0 || i2<0)throw new NumberFormatException();
            	}catch(NumberFormatException ex){
            		showMessageDialog(frame, "Please check your input.");
            		return;
            	}
            	if(t3.equals(""))t3=null;
            	else t3="'"+t3+"'";
            	if(t4.equals(""))t4=null;
            	else t4="'"+t4+"'";
            	if(t1.equals("") || t2.equals("")||t1==null||t2==null)
            		showMessageDialog(frame, "Missing mandatory fields.");
            	else{
            		if(with_prescription==0 && is_prescription==1){
            			showMessageDialog(frame, "This is a prescription drug.");
            			return;
            		}
            		try{
						DriverManager.registerDriver(new oracle.jdbc.driver.OracleDriver());
						OracleConnection conn = 
							(OracleConnection)DriverManager.getConnection(
							 "jdbc:oracle:thin:@studora.comp.polyu.edu.hk:1521:dbms",username,pwd);
						Statement stmt = conn.createStatement();
						try{
							stmt.executeQuery("INSERT INTO customer VALUES("+t3+","+t2+", "+t4+")");
							stmt.executeQuery("Commit");
						}catch(SQLIntegrityConstraintViolationException customer_exists){
							try{
								stmt.executeQuery("UPDATE customer SET C_NAME="+t3+", C_LOCATION="+t4+" WHERE phone_number="+t2);
							}catch(SQLException something_weird){
								showMessageDialog(frame, "An error occured.");
								destroy();
								new HomePage();
							}
						}
						String realdname=dname==null?null:"'"+dname+"'";
						stmt.executeQuery("INSERT INTO buy VALUES('"+pname+"',"+realdname+", 1+(SELECT MAX(t_id) FROM buy),"+t2+","+t1+","+with_prescription+")");
	             		stmt.executeQuery("Commit");
	                	conn.close();
	                	showMessageDialog(frame, "Order completed.");
	                	destroy();
	                	new HomePage();
	                
	                }catch(SQLException ex){
	                	showMessageDialog(frame, "An error occured.");
	                	destroy();
	                	new HomePage();
	                }
            	}
            });
			panel.add(jb);
			
			
			panel.setVisible(true);
			
			
			size = panel.getPreferredSize();
			panel.setBounds(0, 0, size.width, size.height);
			frame.add(panel);
			
            frame.setDefaultCloseOperation(JFrame.EXIT_ON_CLOSE);
            frame.setSize(900,600);
            frame.setLocation(50,50);
            frame.setVisible(true);
        });
    }

	public final void destroy(){
		if(frame!=null) frame.dispose();
	}
}
